import React from 'react';
import  {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
    <Text>Sayuri</Text>
    <View
    style={{
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    }}>
    <Text> Minha Flor Favorita</Text>
    <Image
    source={{
      uri:'https://images.ecycle.com.br/wp-content/uploads/2022/01/21123700/aaron-burden-0sgOTeDS2Mg-unsplash-scaled.jpg.webp',
    }}
    style={{width:200, height:200}}
    />
    </View>
    <TextInput
    style={{
      heigth:40,
      borderColor: 'yellow',
      borderWidth: 1,
    }}
    defaultValue="Girassol"
    />
    </ScrollView>
  );
};

export default App;